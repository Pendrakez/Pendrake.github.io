package days06;

/**
 * @author Hans
 * @date 2024. 1. 8. - 오전 8:49:09
 * @subject
 * @content
 */
public class Ex01 {

	public static void main(String[] args) {
		char one = '8';
		
		one = '한';
		System.out.println( Character.isDigit( one ));
		if (Character.isDigit( one)) {
				System.out.println("숫자 O");
				
			
		} else {
				System.out.println("숫자 X");

		}
		
		one = 'A';
		one = 'a';
		one = '한';
		
		one = '한';
		// System.out.println(Character.isAlphabetic(one));
		
			
		

	} // main

} // class
