package days06;

/**
 * @author Hans
 * @date 2024. 1. 8. - 오후 5:38:17
 * @subject 문제풀이 [별모양 배열로 도형만들기]
 * @content
 *  모양
 * 
**
***
****
 */
public class Ex10_03 {

	public static void main(String[] args) {
		for (int i = 0; i <= 1; i++) {
			
			// ****
			for (int a = 1; a <= 1; a++) {
				System.out.print("****") ;
			} 
			System.out.println(); break;
		} //
		for (int b = 1; b <= 1; b++) {
			System.out.print("_***") ;
		}
		System.out.println();
		for (int c = 1; c <= 1; c++) {
			System.out.print("__**") ;
		}
		System.out.println();
		for (int d = 1; d <= 1; d++) {
			System.out.print("___*") ;
		}
		System.out.println();
		

	} // main

} // class
