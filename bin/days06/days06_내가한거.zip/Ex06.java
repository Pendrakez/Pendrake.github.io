package days06;

import java.util.Scanner;

/**
 * @author Hans
 * @date 2024. 1. 8. - 오후 4:00:59
 * @subject 본인의 영어이름을 입력받아서 char [] 로 변환후 foreach문을 사용해서 출력하는 코딩을 하세요.
 * @content
 */
public class Ex06 {

	public static void main(String[] args) {
		
		String name;
		Scanner sc = new Scanner(System.in);
		//name = sc.next();
		name = sc.nextLine(); // Han Jae Ho
		System.out.printf("name : %s\n", name);
		int arrayLength = name.length();
		
		char [] nameCharArray = new char [arrayLength];
		for (int i = 0; i < arrayLength; i++) {
			nameCharArray[i] = name.charAt(i);
			
		} // nameCharArray[] 배열에 대입하는 for문
		
		for (char c : nameCharArray) {
			System.out.printf("'%c'\n", c);
		} // char c에 nameCharArray 대입하는 for문

	} // main

} // class
