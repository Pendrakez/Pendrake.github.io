package days06;

/**
 * @author Hans
 * @date 2024. 1. 8. - 오후 4:17:50
 * @subject  이중for문
 * @content 
 * 
 */
public class Ex07 {

	public static void main(String[] args) {
		/* 2 times table / 2nd level
		2*1 =
		2*2 =
		2*3 =
		2*4 =
		2*5 =
		2*6 =
		2*7 =
		2*8 =
		2*9 = 18
		 */

		// d=2
		// 2단
		//  ㄴ i=1,2,3,4,5,6,7,8,9 		i =10
		// d=3
		// 3단
		//  ㄴ i=1,2,3,4,5,6,7,8,9 		i =10
		// d=9
		// 9단
		//  ㄴ i=1,2,3,4,5,6,7,8,9 		i =10
		// d 10 ;
		for (int d = 2; d <= 9; d++) {
			System.out.printf("%d단\n", d);
			for (int i = 1; i <= 9; i++) {
				System.out.printf("%d * %d = %d\n", d, i, d*i);
			} // for i
		
		} // for d
	
	} // main

}// class
