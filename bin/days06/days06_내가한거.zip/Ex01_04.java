package days06;

/**
 * @author Hans
 * @date 2024. 1. 8. - 오전 10:35:31
 * @subject
 * @content
 */
public class Ex01_04 {

	public static void main(String[] args) {

		String strCheck = "#!@$";
		char one = '#';



		for (int  i = 0;  i < strCheck.length(); i++) {
			System.out.printf("%d - '%c'\n", i , strCheck.charAt(i));






			/* [2]
				if ( one == strCheck.charAt(i) ) {
					System.out.println("특수 문자 입니다.");
					// 특수문자
					break;
				} else {
					System.out.println("특수 문자가 아닙니다.");

				} */

		} // for


	} // main

} // class
