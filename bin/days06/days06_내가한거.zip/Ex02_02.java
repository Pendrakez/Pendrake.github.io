package days06;

import java.util.Arrays;
import java.util.Random;

/**
 * @author Hans
 * @date 2024. 1. 8. - 오후 12:30:34
 * @subject 람다식과 스트림 설명
 * @content
 */
public class Ex02_02 {
	
	public static void main(String[] args) {
		
		int max = new Random().ints(5, 16).limit(10).max().getAsInt();
		System.out.println( max );
		
		/*
		int [] m = new Random().ints(5,16).limit(10).toArray();
		System.out.println(Arrays.toString(m));
		*/
		
	}// main

} // class
