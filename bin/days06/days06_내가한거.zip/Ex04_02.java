package days06;

/**
 * @author Hans
 * @date 2024. 1. 8. - 오후 2:43:47
 * @subject 알파벳(대,소문자) 코드 및 문자를 출력하는  코딩을 하세요.
 * @content ( 조건 : 한 라인에 10개씩 출력 )
 */
public class Ex04_02 {

	public static void main(String[] args) {

		for (int i = 'A', count = 1, lineNumber = 1; i <= 'z'; i++) {
			//if ('Z' < i && 97 > 'a') continue; {

			if ( Character.isAlphabetic(i)) {
				
				if ( count % 10 == 1) {
					System.out.printf("%d: ", lineNumber++);
					
				}
				
				System.out.printf("%c(%03d) ", (char)i, i);
				/*
				if ( Character.isUpperCase(i) ) { // 대문자
					if(i % 10 == 4) System.out.println(); // 대문자 %10 == 4개행
				}else { // 소문자
					if(i % 10 == 0) System.out.println(); // 소문자 %10 == 0개행
				}
				*/
				if(i % 10 == 0) System.out.println();
				count++;

			} // if

		}// for

	} // main

} // class