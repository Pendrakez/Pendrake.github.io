package days06;

public class Ex10_05 {

	public static void main(String[] args) {
		for (int a = 1; a <= 1; a++) {
			System.out.print("*") ;
		} System.out.println();
		
		//
		for (int b = 1; b <= 1; b++) {
			System.out.print("_*") ;
		}
		System.out.println();
		for (int c = 1; c <= 1; c++) {
			System.out.print("__*") ;
		}
		System.out.println();
		for (int d = 1; d <= 1; d++) {
			System.out.print("___*") ;
		}
		System.out.println();
		for (int e = 1; e <= 2; e++) { 
			System.out.print("____*\n") ;
		} 
		for (int f = 1; f <= 1; f++) {
			System.out.print("___*") ;
		}
		System.out.println();
		for (int g = 1; g <= 1;g++) {
			System.out.print("__*") ;
		}
		System.out.println();
		for (int h = 1; h <= 1; h++) {
			System.out.print("_*") ;
		}
		System.out.println();
		for (int i = 1; i <= 1; i++) {
			System.out.print("*") ;

		}

	} // main
} // class

