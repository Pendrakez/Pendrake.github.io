package days06;

import java.util.Scanner;

/**
 * @author Hans
 * @date 2024. 1. 8. - 오후 12:45:56
 * @subject
 * @content
 */
public class Ex03_02 {

	public static void main(String[] args) {
		char one;
		// Syntax error on token "continue", invalid VariableDeclaratorId
		char con= 'y';
		
		boolean condition = true;
		do {
			Scanner sc = new Scanner(System.in);
			System.out.print("> 한 문자 입력 ?");
			one = sc.next().charAt(0);
			System.out.printf("one='%c'\n", one);
			
			System.out.print("> 더 입력 ?");
			con = sc.next().charAt(0);
		
		} while (con == 'y' || con == 'Y');
		
		System.out.println("end");
	
		
		
		
		
	} // main

} // class
