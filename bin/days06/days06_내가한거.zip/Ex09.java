package days06;

/**
 * @author Hans
 * @date 2024. 1. 8. - 오후 5:28:32
 * @subject
 * @content
 */
public class Ex09 {

	public static void main(String[] args) {
		
		// ****
		// ****
		// ****
		// ****
		
		/* [1]
		System.out.println("****");
		System.out.println("****");
		System.out.println("****");
		System.out.println("****");
		*/
		
		// [2]
		/*
		for (int i = 1; i <= 4; i++) {
			System.out.println("****");
		} //
		*/ 
		
		// [3]
		//System.out.println("****");
		// System.out.print("*") x 4 + 개행;
		for (int i = 1; i <= 4; i++) {
			// ****
			for (int j = 1; j <= 4; j++) {
				System.out.print("*") ;
			}
			System.out.println();
		} //

	} // main

} // class
