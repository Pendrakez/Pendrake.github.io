package days06;

import java.util.Scanner;

/**
 * @author Hans
 * @date 2024. 1. 8. - 오전 8:49:09
 * @subject
 * @content
 */
public class Ex01_05 {

	public static void main(String[] args) {
		
		int a, b, c;
		
		//try { Scanner sc = new Scanner(System.in);
		
		
		// [3]
		// Math 클래스 : 산술적 기능이 구현된 클래스
		// 0.0 <= double Math.random() < 1.0
		// 0 ~ 100 국어점수
		
		// max = Math.max()
		// min = Math.min()
		
		//int max = Math.max(a, b);
		//max = Math.max(max, c);
		
		//int min = Math.min( Math.min(a, b) , c);
		// Math.pow(3, 2); Type = double
			
		//} //catch (Exception e) {
			
		//}
		
			
		

	} // main

} // class

