
package days06;

/**
 * @author Hans
 * @date 2024. 1. 8. - 오후 4:49:06
 * @subject 구구단 가로출력
 * @content
 */
public class Ex07_03 {

	public static void main(String[] args) {

		/*
		int d = 2;
		int i = 1;

		while ( d <= 9) {
			i = 1; // 디버깅해서 추석해 보면서 찾기
			System.out.printf("%d단\n", d);
			while ( i <= 9) {
				System.out.printf("%d * %d = %d\n", d, i, d*i);
				i++;
				System.out.printf("%d단\n", d);
			} // while i
			d ++;
		} // while d
		*/



		
		for (int d = 2; d <= 9; d++) {
			// System.out.printf("[%d단]", d);
			for (int i = 1; i <= 9; i++) {
				System.out.printf("%d*%d=%02d ", d, i, d*i);
			} // for i
			System.out.println();
		} // for d

		
	} // main

} // class
