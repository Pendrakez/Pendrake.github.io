package days06;

import java.util.Arrays;
import java.util.Scanner;
/**
 * @author Hans
 * @date 2024. 1. 8. - 오후 4:11:22
 * @subject
 * @content
 */
public class Ex06_02 {

	public static void main(String[] args) {
		
		String name;
		Scanner sc = new Scanner(System.in);
		//name = sc.next();
		name = sc.nextLine(); // Han Jae Ho
		System.out.printf("name : %s\n", name);
		
		// String.toCharArray()
		// 1) String -> char[] 변환하는 함수(매서드)
		
		char [] nameCharArray = name.toCharArray();
		
		// 배열 안의 값을 확인하는 용도로 Array.toString() 매서드를 사용.
		// [H, a, n, , J, a, e, , H, o]
		
		System.out.println( Arrays.toString( nameCharArray ));
		
		// 2) char[] -> String 변환하는 방법 : String.valueOf() 매서드(함수)
		name = String.valueOf(nameCharArray);
		System.out.printf("name : %s\n", name);
		

	} // main

} // class
