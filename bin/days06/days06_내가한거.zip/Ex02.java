package days06;

import java.util.Iterator;

/**
 * @author Hans
 * @date 2024. 1. 8. - 오후 12:02:25
 * @subject 2번 문제
 * @content 정수를 10개 저장할 배열 m 을 선언하고 5<= n && n <= 15 범위의 임의의 정수로 채워넣은 후 배열의 각 요소를 출력하는 코딩을 하세요.
 */
public class Ex02 {

	public static void main(String[] args) {
		
		int[] m = new int[10];
		int n = 0;
		
		for (int i = 0; i < m.length; i++) {
			System.out.printf("");
		}
		
		for (int i = 0; i < m.length ; i++) {
			System.out.printf("m[%d]=%d\n", i, m[i]);
			
		
			
		} // for
		
		//[추가문제] m 배열의 가장 큰 값과 가장 작은 값을 출력.
		
		int max = m[0], min = m[0];
		for (int i = 0; i < m.length; i++) {
			max = Math.max(max, m[i]);
			min = Math.min(min, m[i]);
			
		}
		
		System.out.printf(" max:%d\n", max);
		System.out.printf(" min:%d\n", min);
		
		
		
		/*for (int i = 0; i < m.length; i++) {
			int max = Math.max(i, n);
			int min = Math.min(i, n);
			System.out.printf("m[%d]=%d\n", max, n[i]);
			
		}*/ // for
		

	} // main

} // class
