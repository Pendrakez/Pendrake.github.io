package days06;

/**
 * @author Hans
 * @date 2024. 1. 8. - 오전 10:35:31
 * @subject
 * @content
 */
public class Ex01_03 {

	public static void main(String[] args) {
	      
	      char one = '$';
	      String strCheck = "#@$!";
	      
	      // boolean String.atches( regex );
	      
	      // String regex = " one == '#' || one == '@' || one == '$' || one == '!'";
	      // 숫자 \d{1-3} == [0-9][1,3]
	      // [0-9] = [0123456789]
	      // [A-Za-z0-9]
	      // [aeiouAEIOU]
	      // 대괄호 안에는 그것 중에 하나라는 읨
	      
	      String regex = "[!@#$]";
	      if ( (one+"").matches(regex) ) {
			System.out.println("특수문자 O");
		} else {
			System.out.println("특수문자 X");
		}
	      
	        

	   } // main

	} // class

