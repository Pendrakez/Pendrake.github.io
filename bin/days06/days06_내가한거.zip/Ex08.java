package days06;

/**
 * @author Hans
 * @date 2024. 1. 8. - 오후 5:16:48
 * @subject LG 공채 문제
 * @content [이름(label)이 붙은 반복문]
 * 			break 라벨명; continue 라벨명;
 */
public class Ex08 {

	public static void main(String[] args) {
		
		OUT:for (int i = 2; i <= 9 ; i++) {
			IN:for (int d = 1; d <= 9; d++) {
				System.out.printf("%d*%d=%02d ", i, d, i*d);
				if (i*d == 24) break OUT;
				
			} // for d
			System.out.println();
		} // for i

	} // main

} // class
