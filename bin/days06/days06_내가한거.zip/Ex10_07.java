
package days06;

public class Ex10_07 {

	public static void main(String[] args) {
		
		for (int a = 1; a <= 1; a++) {
			System.out.print("__*") ;
		} System.out.println();
		
		//
		for (int b = 1; b <= 1; b++) {
			System.out.print("_***") ;
		}
		System.out.println();
		for (int c = 1; c <= 1; c++) {
			System.out.print("*****") ;
		}
		System.out.println();
		for (int d = 1; d <= 1; d++) {
			System.out.print("_***") ;
		}
		System.out.println();
		for (int e = 1; e <= 1; e++) { 
			System.out.print("__*") ;
		}

	} // main

} // class
