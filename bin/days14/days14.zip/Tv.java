package days14;

public class Tv {
	// 맴버변수(필드)
	public String color;
	public boolean power;
	public int channel;
	
	
	// 맴버함수(메서드)
	public void power() {
		power = !power;
	}
	
	public void channelup() {
		channel++;
	
	}
	
	public void channelDown() {
		channel--;
	
	}

}
