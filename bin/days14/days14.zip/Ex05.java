package days14;

/**
 * @author Hans
 * @date 2024. 1. 18. - 오전 11:52:36
 * @subject
 * @content
 */
public class Ex05 {

	public static void main(String[] args) {
		// 1) 객체(클래스) 복사 copy
		// 2) 객체(클래스) 복제 clone
		
		Tv tv1 = new Tv();
		// Tv tv2 = new Tv();
		Tv tv2 = tv1;
		

	} // main

} // class
