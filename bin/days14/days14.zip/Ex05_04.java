package days14;

/**
 * @author Hans
 * @date 2024. 1. 18. - 오후 12:33:56
 * @subject
 * @content
 */
public class Ex05_04 {

	public static void main(String[] args) {
		// 클래스(객체) 복제 == clone  / 새로운게 만들어지는 것
		Point p1 = new Point();
		p1.x = 10;
		p1.y = 20;
		
		// 인스턴스 					      객체
		// [10][20] ------------------->[0x100]p1
		
		// 복제(clone) 					      객체
		// [10][20] ------------------->[0x100]p2
		Point p2 = new Point();
		p2.x = p1.x;
		p2.y = p1.y;
		
		System.out.printf("> x=%d, y=%d\n" , p1.x, p1.y );
		System.out.printf("> x=%d, y=%d\n" , p2.x, p2.y );
		

	} // main

} // class
