package days14;

import java.util.Random;
import java.util.Scanner;

/**
 * @author Hans
 * @date 2024. 1. 18. - 오전 11:13:38
 * @subject
 * @content
 */
public class Ex03_02 {

	public static void main(String[] args) {
		
		// 본인의 이름 출력
		// System 클래스 - 표준 입출력 스트림 필드
		//					표준 입출력 매서드
		// System s1 = new System(); X 인스턴스화 할 수 없는
		
		Scanner sc = new Scanner(System.in);
		Random rnd = new Random();
		
		// [문제] 스캐너 객체를 생성만 하는 코딩을 하세요. 
		// 		인스턴스화 -> new Scanner(System.in) 만 적어야하는게 정답.
	} // main

} // class
