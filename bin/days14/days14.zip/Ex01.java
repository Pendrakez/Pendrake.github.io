package days14;

/**
 * @author Hans
 * @date 2024. 1. 18. - 오전 10:12:39
 * @subject 
 * @content
 */
public class Ex01 {
	// 맴버변수
	public static int age = 10;
	String name;
	
	// 맴버함수(매서드)
	public static void main(String[] args) {
		// 맴버변수 X	ㄴ 메서드
		// 지역변수

	}

}
