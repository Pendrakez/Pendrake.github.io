package days14;

/**
 * @author Hans
 * @date 2024. 1. 18. - 오전 10:25:58
 * @subject Tv 클래스 선언 -> 객체 생성 후 사용
 * @content
 */
public class Ex02 {

	public static void main(String[] args) {
		// 지역변수
		// int i = 100;
		
		// 지역변수, 참조변수(주소값을 가지고 있기 때문에), 배열명
		// int []m = new int[3];
		// 배열명[첨자값]
		
		// 지역변수, 참조변수, **객체(명)
		// 객체 tv1 선언
		// 변수만 선언해도 객체를 선언했다고 봐도 무방
		Tv tv1 = null;
		
		// 객체명.필드명
		// 객체명.메서드명();
		// .도 맴버를 가르키는 연산자

		tv1 = new Tv(); // (생성된 객체) 객체를 생성하는 코딩 -> 인스턴스화
		
		// 필드가 초기화x	객체명.필드명	기본값
		/*
		System.out.println( tv1.color ); // null
		System.out.println( tv1.channel ); // 0
		System.out.println( tv1.power ); // false
		*/
		
		// 객체명.필드명
		// 배열명[index]
		
		//
		tv1.power();
		System.out.println("Tv : " + (tv1.power ? "ON" : "OFF") );
		tv1.channelup();
		tv1.channelup();
		tv1.channelup();
		System.out.println("현재 채널 : " + tv1.channel);
		tv1.power();
		System.out.println("Tv : " + (tv1.power ? "ON" : "OFF") );
		System.out.println("end");
	} // main

} // class
