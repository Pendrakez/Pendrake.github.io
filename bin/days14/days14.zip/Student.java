package days14;

/**
 * @author Hans
 * @date 2024. 1. 18. - 오전 11:30:02
 * @subject package == default
 * @content
 */
class Student {

}
