package days14;

/**
 * @author Hans
 * @date 2024. 1. 18. - 오전 11:06:08
 * @subject
 * @content
 */
public class Ex03 {

	public static void main(String[] args) {
		/* The local variable m may not have been initialized
		// int [] m = null;
		int [] m = new int[3]; // 0, 1, 2
		
		// NullPointerException
		// ArrayIndexOutOfBoundsException
		System.out.println( m[3] );
		*/

		// The local variable tv1 may not have been initialized
		// NullPointerException -> 객체가 생성이 안된 경우에 나오는 에러
		Tv tv1 = null;
		System.out.println( tv1.channel );
		
	} // main

} // class
